using System;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using AddinExpress.OL;
using Addin.Outlook.UI;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Outlook;

namespace AttachmentBridge
{
    public partial class ThisAddIn
    {

        public ADXOlFormsManager FormsManager = null;
        public ADXOlFormsCollectionItem PushToEpicFormRegionItem;

        /// <summary>
        /// Use this event to initialize regions and connect to the events of the ADXOlFormsManager class
        /// </summary>
        private void FormsManager_OnInitialize()
        {
            #region PushToEpicFormRegion

            // TODO: Use the PushToEpicFormRegionItem properties to configure the region's location, appearance and behavior.
            // See the "The UI Mechanics" chapter of the Add-in Express Developer's Guide for more information.

            PushToEpicFormRegionItem = new ADXOlFormsCollectionItem
            {
                Cached = ADXOlCachingStrategy.OneInstanceForAllFolders,
                ExplorerLayout = ADXOlExplorerLayout.BottomReadingPane,
                ExplorerItemTypes = ADXOlExplorerItemTypes.olMailItem,
                InspectorLayout = ADXOlInspectorLayout.BottomSubpane,
                InspectorItemTypes = ADXOlInspectorItemTypes.olMail,
                UseOfficeThemeForBackground = true,
                RestoreFromMinimizedState = true,
                FormClassName = typeof(PushToEpicFormRegion).FullName,
                Splitter = ADXOlSplitterBehavior.None,

            };

            this.FormsManager.Items.Add(PushToEpicFormRegionItem);
            #endregion
        }

    }
}
