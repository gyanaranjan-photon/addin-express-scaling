using System;
using System.Windows.Forms;
using System.Drawing;
using AddinExpress.OL;

namespace AttachmentBridge
{
    public partial class PushToEpicFormRegion : AddinExpress.OL.ADXOlForm
    {
        public PushToEpicFormRegion()
        {
            InitializeComponent();
        }
    }
}

